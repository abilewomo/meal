# GIT-FIT


## Table of Contents
* [Description](#description)
* [General Info](#general-information)
* [Technologies Used](#technologies-used)
* [Features](#features)
* [Screenshots](#screenshots)
* [Setup](#setup)
* [Usage](#usage)
* [Project Status](#project-status)
* [Room for Improvement](#room-for-improvement)
* [Acknowledgements](#acknowledgements)
* [Contact](#contact)
<!-- * [License](#license) -->

## Description
Who you’re working with (you and your team members)?

- There are 5 team members for this Project: Michael Lehmann, Michael Donato, Michael Canales, Stanley Nwajiaku, and Dalen Whitlock

What you’re creating?

- We are creating a fitness app that can help plan and manage workouts and diets.

Who you’re doing it for, your audience (may be same as the previous question)?

- We are trying to make this for those wanting to organize their lifestyle of trying to live healthier, whether through their diet, working out, or both.

Why you’re doing this, the impact or change you hope to make?

- The purpose of our project is to make planning and tracking all the details behind fitness and health easier to manage so that the hardest part is the physical part behind living healthier, not the mental part.

## General Information
![Alt text](GIT-FIT_img-1.png)

- This project will help users manage and plan their workouts and nutritional balance as well as track weight gain/loss progress and performance improvement.

<!-- You don't have to answer all the questions - just the ones relevant to your project. -->


## Technologies Used
- Python
- Flask
- HTML / CSS / Javascript


## Features
> Journal:

- Plan workouts or diets to organize plan
- User Story: As a user, I would like a journal for my workouts so that I can track my progress over time.

> Calendar:

- Schedule and review past workouts to view progress and make new goals
- User Story: As a user I would like a record of my data so that I can plan workouts and manage my progress.

> Exercise Index:

- Option of a selection of workouts, exercises to choose from
- User Story: As a user, I would like to see different workouts for certain muscle groups  I am working on.

## Screenshots
![Example screenshot](./img/screenshot.png)
<!-- If you have screenshots you'd like to share, include them here. -->


## Setup
What are the project requirements/dependencies? Where are they listed? A requirements.txt or a Pipfile.lock file perhaps? Where is it located?

Proceed to describe how to install / setup one's local environment / get started with the project.

## Sprint 1
![Alt text](Sprint1_image.png)

## Contributions
- **Stanley**: "Worked on the frontend design and layout of the website"
	- `Jira Task: SCRUM-16  "Add a 'workout' and 'progress' page"`
		- reference: https://bitbucket.org/cs3398f23betazoids/%7B8d75ab45-193c-40b7-a4f5-f8c3a949680a%7D/branch/feature/SCRUM-16-add-a-workout-and-progress-page
	- `Jira Task: SCRUM-18 "Research and integrate GitHub code search functionality"` 
		- reference: https://bitbucket.org/cs3398f23betazoids/%7B8d75ab45-193c-40b7-a4f5-f8c3a949680a%7D/branch/feature/SCRUM-18-research-and-integrate-github-c
	- `Jira Task: SCRUM-20 "Enhance all pages of the fitness website, includes adding background images."`
		- reference: https://bitbucket.org/cs3398f23betazoids/%7B8d75ab45-193c-40b7-a4f5-f8c3a949680a%7D/branch/feature/SCRUM-20-enhance-the-different-pages-of-website
		
- **Dalen**: "Set up the database program and added tables to provide information and hold user inputted information."
	- `Jira Task: Install/Set up database program.`
		- reference: https://bitbucket.org/cs3398f23betazoids/%7B8d75ab45-193c-40b7-a4f5-f8c3a949680a%7D/commits/be3090ef9039b2e7453a3a9ca06709a7387420fa
	- `Jira Task: Create tables for user info.` 
		- reference: https://bitbucket.org/cs3398f23betazoids/%7B8d75ab45-193c-40b7-a4f5-f8c3a949680a%7D/commits/19aad83e2a860789ac159ef954430b89675f2f3c
	- `Jira Task: Create tables for workouts and exercises.`
		- reference: https://bitbucket.org/cs3398f23betazoids/%7B8d75ab45-193c-40b7-a4f5-f8c3a949680a%7D/commits/69653ac3871aed438f2beded8615fad471a57b53
    - `Jira Task: Create tables to hold workout and exercise information.`
		- reference: https://bitbucket.org/cs3398f23betazoids/%7B8d75ab45-193c-40b7-a4f5-f8c3a949680a%7D/commits/22ae81d4a5126011c3d0d8c1b628a669750f06aa
    - `Jira Task: Create tables for meal plans and nutritional balance.`
		- reference: https://bitbucket.org/cs3398f23betazoids/%7B8d75ab45-193c-40b7-a4f5-f8c3a949680a%7D/commits/9c4ebf662d1bc9957d2800c36085ff9afbcd7c8b
		
- **Michael C**: "Worked on the frontend design."
	- `Jira Task: Design and implement a login page.`
		- reference: https://cs3398f23betazoids.atlassian.net/jira/software/projects/SCRUM/issues/SCRUM-37

- **Michael Lehmann**: "Copied Flask Python webapp to be a starting point. Created Exercises page and Journal page. Added table script and Google Calendar as placeholders for now."
	- `Jira Task: SCRUM-12 "Copy the Flask Python Web App to use as a template"`
		- reference: https://bitbucket.org/cs3398f23betazoids/fitness-app/commits/b8bba2aaf71d4d39c4d68a26f01b66879b25a406
	- `Jira Task: SCRUM-26 "Design a page to display workout types"`
		- reference: https://bitbucket.org/cs3398f23betazoids/%7B8d75ab45-193c-40b7-a4f5-f8c3a949680a%7D/commits/1f7f8881cba2fe2b0b170dd592a22d2b858a2e69
	- `Jira Task: SCRUM-14 "Design Journal page"`
		- reference: https://bitbucket.org/cs3398f23betazoids/%7B8d75ab45-193c-40b7-a4f5-f8c3a949680a%7D/commits/9095df5f06a807eefa192719fbea4b912dc5bb50
	- `Jira Task: SCRUM-13 "Modify template to include pages we will need"`
		- note: task was too vague and therefore was not completed. no branch was made for this task, as it overlapped with other tasks.
	
	**Michael Donato**: Worked on frontend design and layout
	- ' Jira Task  Researching CSS and styling'
	- reference: https://bitbucket.org/cs3398f23betazoids/fitness-app/commits/de834d7b47138e45853a1967ec09798c4b2bab16
 
 
	
## Next Steps
- Stanley
	- make the exercise page able to fetch data and display results of different exercises and their details.

- Michael C
	-Implement a login function
	-Implement a create account function

- Dalen
	- I need to connect the local MySQL database so that our code can access it as well as create a firebase database so that it can be accessed on a server.	

- Michael Lehmann
	- Research MySQL to learn how to integrate it into our site for user info, workouts, exercise list, etc.
	- Figure out if Google Calendar will work for saving user progress
	- Research options for hosting website online
	- Work on implementing login functionality
- Michael Donato
	 - Make some change to the interface to best fit users(implment single scroll function, collasable header)
## Usage
How does one go about using it?
Provide various use cases and code examples here.

<!-- `write-your-code-here` -->


## Project Status
Project is: _in progress_ / _complete_ / _no longer being worked on_. If you are no longer working on it, provide reasons why.


## Room for Improvement
Include areas you believe need improvement / could be improved. Also add TODOs for future development.

Room for improvement:
- Improvement to be done 1
- Improvement to be done 2

To do:
- Feature to be added 1
- Feature to be added 2


## Acknowledgements
Give credit here.
- This project was inspired by...
- This project was based on [this tutorial](https://www.example.com).
- Many thanks to...


## Contact
<!-- Created by [@flynerdpl](https://www.flynerd.pl/) - feel free to contact me! -->

<!-- Optional -->
<!-- ## License -->
<!-- This project is open source and available under the [... License](). -->

<!-- You don't have to include all sections - just the one's relevant to your project -->