import os
import sys 
import re
import requests
from client import app
from markupsafe import escape
sys.dont_write_bytecode = True
from flask import Flask, flash, render_template, redirect, url_for, request, session, abort, jsonify, jsonify,Flask
from flask import Flask, send_from_directory
from ._pys.forms import SignupForm, LoginForm, UserInfo, EditProfileForm
from ._pys.models import User
import client._pys.db as db
from mongoengine import *
from flask import jsonify
from dotenv import load_dotenv


load_dotenv()
app = Flask(__name__, static_folder='static')

app.config['SECRET_KEY']='LongAndRandomSecretKey'
app.config['PERMANENT_SESSION_LIFETIME']=1800 # Time until timeout in secapp.config['PERMANENT_SESSION_LIFETIME']=1800 # Time until timeout in sec

# Set the paths to the React build directory and Flask static directory
react_build_directory = os.path.join(os.path.dirname(os.path.abspath(__file__)), '..', 'exercisepage', 'build')

# Routing

# Require login to access user pages
def is_user_authenticated():
    return 'username' in session

# Use the before_request decorator to check authentication
@app.before_request
def require_login():
    # List of routes that require authentication
    protected_routes = ['/home', '/exercises', '/journal', 'nutrition', 'profile']
    
    if request.path in protected_routes and not is_user_authenticated():
        return redirect(url_for('login'))  # if user not signed in go to login page

# Login function
@app.route("/", methods=["GET", "POST"])
def login():
    form = LoginForm() # Assign login form as form

    if 'username' in session:
        return redirect(url_for('home'))
    
    if request.method == 'POST': 
        if form.validate() == False: # If invalid form return
            return render_template('login.html', form=form)
        else:
            if not form.user_exist():
              form.username.errors.append("Incorrect username. User does not exist")
              return render_template('login.html', form=form)
            elif not form.password_correct():
              form.password.errors.append("Incorrect Password")
              return render_template('login.html', form=form)
            else:
              current_user = db.get_session_user(form.username.data)
              session['username'] = form.username.data # If user already exists go to user session in home
              session['firstname'] = current_user["firstname"]
              session['lastname'] = current_user["lastname"]
              session['age'] = current_user["age"]
              session['weight'] = current_user["weight"]
              session['height'] = current_user["height"]
              return redirect(url_for('home'))
            
                
    elif request.method == 'GET':
        return render_template('login.html', form=form)

# Sign up page
@app.route('/sign-up')
def gosignup():
    return redirect(url_for('register', step=1))

# Sign up function
@app.route('/sign-up/<int:step>', methods = ['GET', 'POST'])
def register(step):
    forms = { # Assign signup forms
        1: SignupForm(), 
        2: UserInfo()
    }

    form = forms.get(step, 1)
    
    if 'username' in session:
        return redirect(url_for('home')) 
    
    if request.method == 'POST':
        if SignupForm.validate(form) == False:
            return redirect(url_for('register', step=step)) # If invalid form return
        else:
            if step==1:
              session['step{}'.format(step)] = form.data
              if SignupForm.email_exist(form):
                form.email.errors.append("Email is already in use")
                form = form
                content = {
                    'step': step, 
                    'form': form,
                }
                return render_template('sign-up.html', **content)
              if SignupForm.user_exist(form):
                form.username.errors.append("Username is taken")
                form = form
                content = {
                    'step': step, 
                    'form': form,
                }
                return render_template('sign-up.html', **content)
              if not SignupForm.password_verify(form):
                form.verify.errors.append("Passwords do not match")
                form = form
                content = {
                    'step': step, 
                    'form': form,
                }
                return render_template('sign-up.html', **content)

            if step < len(forms):
                # Redirect to next step
                return redirect(url_for('register', step=step+1))
            else:
                newuser = User(session['step1']['email'], session['step1']['username'], session['step1']['password'], form.firstname.data, 
                               form.lastname.data, form.age.data, form.weight.data, form.height.data)
                db.insert_data(newuser) # Insert valid form information to database
                session['username'] = newuser.username
                return redirect(url_for('login'))
                
    # If form data for this step is already in the session, populate the form with it
    if 'step{}'.format(step) in session:
        form.process(data=session['step{}'.format(step)])

    content = {
        'step': step, 
        'form': form,
    }

    return render_template('sign-up.html', **content)

# Logout function
@app.route('/logout')
def logout():
    session.clear
    session.pop('username', None)
    return redirect(url_for('login')) 

@app.route('/home')
def home():
 # Define Plot Data 
 labels = [
    'January',
    'February',
    'March',
    'April',
    'May',
    'June',
    'July',
    'August',
    'September',
    'October',
    'November',
    'December',
 ]
 
 data = [160, 165, 165, 175, 185, 190, 200]
 return render_template(template_name_or_list='home.html', session=session, data=data, labels=labels)

@app.route('/about')
def about():
  return render_template('about.html')

# Serve React app on the exercises route
@app.route('/exercises')
@app.route('/exercises/<path:path>')
def exercises(path='index.html'):  # Default path is index.html
    # This will ensure that all paths under '/exercises', like '/exercises/subpath'
    # are served by React's index.html, allowing React Router to handle the frontend routing.
    if not re.match(r'^static/.*', path):
        # Anything not starting with 'static' is assumed to be a React route
        return send_from_directory(react_build_directory, 'index.html')
    else:
        # If the path starts with 'static', serve the corresponding static file
        return send_from_directory(os.path.join(react_build_directory, 'static'), path[7:])
    

@app.route('/journal')
def journal():
    return render_template('journal.html')

@app.route('/nutrition/mealplan', methods=['GET'])
def show_meal_plan_form():
    # Simply render the form page when the '/nutrition/mealplan' endpoint is accessed with a GET request
    return render_template('nutrition/mealplan.html')

@app.route('/nutrition/mealplan', methods=['POST'])
def nutrition_meal_plan():
    query = request.form['query']

    url = "https://api.edamam.com/api/recipes/v2"
    params = {
        "type": "public",  # The type parameter is required for the new version of the API.
        "q": query,
        "app_id": os.getenv("EDAMAM_APP_ID"),
        "app_key": os.getenv("EDAMAM_API_KEY")
    }
    response = requests.get(url, params=params)
    
    if response.ok:
        data = response.json()
        return render_template('nutrition/mealplan.html', data=data)
    else:
        error = "Error fetching recipes: " + response.text
        return render_template('nutrition/mealplan.html', error=error)
    
@app.route('/autocomplete')
def autocomplete():
    query = request.args.get('query', '')
    response = requests.get(
        f"{EDAMAM_BASE_URL}/auto-complete?q={query}&app_id={EDAMAM_APP_ID}&app_key={EDAMAM_API_KEY}&limit=10"
    )
    if response.status_code == 200:
        return jsonify(response.json())
    else:
        return jsonify([])

@app.route('/nutrition/calories')
def nutrition_calories():
    return render_template('Nutrition/calories.html')

@app.route('/profile')
def profile():
    return render_template('profile.html', session=session)

@app.route('/edit_profile', methods=['GET', 'POST'])
def edit_profile():
    form = EditProfileForm()
    if request.method == 'POST':
        if form.validate() == False:
            return render_template('edit_profile.html', form=form)
        else:
            username = session['username']
            updated_user_info = {
                "firstname": form.firstname.data,
                "lastname": form.lastname.data,
                "age": form.age.data,
                "weight": form.weight.data,
                "height": form.height.data
            }
            result = db.update_user_info(username, updated_user_info)
            
            session['firstname'] = form.firstname.data
            session['lastname'] = form.lastname.data
            session['age'] = form.age.data
            session['weight'] = form.weight.data
            session['height'] = form.height.data
        
            if result:
                flash('Profile updated successfully', 'success')
                return redirect(url_for('profile'))
            else:
                flash('No user found with the provided username. Profile not updated.', 'danger')
                
    return render_template('edit_profile.html', form=form)

@app.route('/api/add_event', methods=['POST'])
def add_event():
    data = request.get_json()
    data['username'] = session.get('username') #insert the username for the user who added the event to the calendar
    db.insert_event(data)
    data['_id'] = str(data['_id'])
    return jsonify(data)

@app.route('/api/get_events', methods=['GET'])
def get_events():
    events = db.retrieve_events(session.get('username'))
    event_list = []

    for event in events:
        event_dict = {
            'title': event['title'],
            'start': event['start'],
            'allDay': event['allDay'],
        }
        event_list.append(event_dict)

    return jsonify(event_list)
