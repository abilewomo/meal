#Need to do the following installs:
# pip install flask-wtf
# pip install email_validator
from flask_wtf import Form, FlaskForm
from wtforms import StringField, SubmitField, validators, PasswordField, IntegerField, FloatField
from wtforms.validators import DataRequired
import client._pys.db as db
from .models import User

# Model for sign up form    
class SignupForm(FlaskForm):
  email = StringField("Email",  [validators.InputRequired("Please enter your email address."), validators.Email("Please enter your email address.")])
  username = StringField("Username",  [validators.InputRequired("Please enter a username.")])
  password = PasswordField('Password', [validators.InputRequired("Please enter a password.")])
  verify = PasswordField('Re-Enter Password', [validators.InputRequired("Please enter your password again.")])
  submit = SubmitField("Next")

  # def __init__(self, *args, **kwargs):
  #   FlaskForm.__init__(self, *args, **kwargs)
  
  # def validate(self):
  #   if not FlaskForm.validate(self):
  #     return False
    
  #   # Check if email is taken
  #   user = db.check_user(self.username.data, self.password.data)
  #   if user:
  #     self.username.errors.append("That email is already taken")
  #     return False
  def __init__(self, *args, **kwargs):
        FlaskForm.__init__(self, *args, **kwargs)

  def validate(self):
    if not Form.validate(self):
      return False
    
  def user_exist(self):  
    # Check for if user exist and password matches
    user = db.check_user(self.username.data)
    if user:
      return True
    else:
      return False
    
  def email_exist(self):
    user = db.check_email(self.email.data)
    if user:
      return True
    else:
      return False
  
  def password_verify(self):
    if self.password.data == self.verify.data:
      return True
    else:
      return False

class UserInfo(FlaskForm):
  firstname = StringField("First name", [validators.InputRequired("Please enter your first name.")])
  lastname = StringField("Last name", [validators.InputRequired("Please enter your last name.")])
  age = IntegerField("Age", [validators.InputRequired("How old are you?.")])
  weight = FloatField("Weight", [validators.InputRequired("What is your current weight?")])
  height = FloatField("Height", [validators.InputRequired("What is your current height?")])
  submit = SubmitField("Create Account")

  def __init__(self, *args, **kwargs):
        FlaskForm.__init__(self, *args, **kwargs)

  def validate(self):
    if not FlaskForm.validate(self):
      return False
  

# Model for login form    
class LoginForm(FlaskForm):
  username = StringField("Username", validators=[DataRequired("Please enter your username.")])
  password = PasswordField("Password", validators=[DataRequired("Please enter your password.")])
  submit = SubmitField("Login")

  def __init__(self, *args, **kwargs):
        FlaskForm.__init__(self, *args, **kwargs)

  def validate(self):
    if not FlaskForm.validate(self):
      return False
    
  def user_exist(self):  
    # Check for if user exist and password matches
    user = db.check_user(self.username.data)
    if user:
      return True
    else:
      return False
    
  def password_correct(self):
    # Check for if user exist and password matches
    user = db.check_user(self.username.data)
    if user and db.check_password(self.username.data, self.password.data):
      return True
    else:
      return False
class AddWorkoutForm(FlaskForm):
  workout = StringField("Workout", validators=[DataRequired("Please enter your workout.")])
  
# Model for edit user info 
class EditProfileForm(FlaskForm):
    firstname = StringField("First Name", validators=[DataRequired("Please enter your first name.")])
    lastname = StringField("Last Name", validators=[DataRequired("Please enter your last name.")])
    age = IntegerField("Age", validators=[DataRequired("Please enter your age.")])
    weight = IntegerField("Weight", validators=[DataRequired("Please enter your weight.")])
    height = IntegerField("Height", validators=[DataRequired("Please enter your height.")])
    
    def __init__(self, *args, **kwargs):
        FlaskForm.__init__(self, *args, **kwargs)

    def validate(self):
      if not Form.validate(self):
        return False