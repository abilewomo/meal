from wtforms import StringField, EmailField, IntegerField, FloatField
from werkzeug.urls import url_parse
from werkzeug.security import generate_password_hash, check_password_hash
from mongoengine import Document, StringField, EmailField

# Class model for a User
class User(Document):
    email = EmailField(unique=True)
    username = StringField(unique=True, required=True)
    password = StringField(required=True)
    firstname = StringField()
    lastname = StringField()
    age = IntegerField()
    weight = FloatField()
    height = FloatField()

    # Initialize values of given fields    
    def __init__(self, email, username, password, firstname, lastname, age, weight, height, *args, **kwargs):
        super(User, self).__init__(*args, **kwargs)
        self.email = email.lower()
        self.username = username
        self.password = password # Using self.set_password causing errors
        self.firstname = firstname.title()
        self.lastname = lastname.title()
        self.age = age
        self.weight = weight
        self.height = height

    # Organize input into proper User field
    def user_dict(self):
        user = {
		    "email": self.email,
		    "username": self.username,
		    "password": self.password,
            "firstname": self.firstname,
		    "lastname": self.lastname,
            "age": self.age,
            "weight": self.weight,
            "height": self.height
	    }
        return user
    
    # Generate password hash
    def set_password(self, password):
        self.password = generate_password_hash(password)
    
# Check password
    def check_password(self, password):
        # return check_password_hash(self.password, password) # Using self.password is causing errors
        return check_password_hash(generate_password_hash(password), password)