import pymongo
from flask import request
from pymongo import MongoClient
import certifi
from .models import User
def get_database():
     
   # Provide the mongodb atlas url to connect python to mongodb using pymongo
   CONNECTION_STRING = "mongodb+srv://qde6:betazoiduser@betazoids.lywxorm.mongodb.net/GIT_FIT"
 
   # Create a connection using MongoClient
   client = MongoClient(CONNECTION_STRING)
 
   # Return connection
   return client['GIT-FIT']
  
# Get the database
database = get_database()

# Insert data into database
def insert_data(user):
  users = database["user_info"] # Assigns collection to insert to
  user = User.user_dict(user) # Organize input into correct User format
  users.insert_one(user) # Inserts the data into database

def check_user(username):
	users = database["user_info"] # Assigns collection to insert to

	if request.method == 'POST':
		username = request.form['username']

		user = {
			"username": username,
		}

		user_data = users.find_one(user) # Checks if user exists
		if user_data == None:
			return False
		else:
			return True, user_data["username"]
		
def check_password(username, password):  	
	users = database["user_info"]

	user = {
		"username": username,
		"password": password
	}
	user = users.find_one(user)
	return user

def get_session_user(username):
	users = database["user_info"]

	user = {
		"username": username
	}
	user = users.find_one(user)
	return user

def check_email(email):
    users = database["user_info"]

    user = {
		"email": email
	}
    user = users.find_one(user)
    return user
	
def insert_event(event):
	events = database["calendar_events"]
	events.insert_one(event)

def retrieve_events(user):
	events = list(database["calendar_events"].find({"username":user}))
	return events

def update_user_info(username, updated_user_info):
    users = database["user_info"]
    
    filter = {"username": username}
    
    update = {
        "$set": updated_user_info
    }
    
    result = users.update_one(filter, update)

    if result.modified_count > 0:
        return True
    else:
        return False