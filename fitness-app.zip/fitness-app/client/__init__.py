# import flask
from flask import Flask
app = Flask(__name__)

# call routes.py to access flask routing
from .routes import app