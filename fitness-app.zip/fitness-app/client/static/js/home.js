// document.addEventListener("DOMContentLoaded", function() {
//     // Sample data
// const data = [
//     { year: 2010, value: 10 },
//     { year: 2011, value: 20 },
//     { year: 2012, value: 15 },
//     // Add more data points
// ];

// // Set up the SVG container dimensions
// const svgWidth = 400;
// const svgHeight = 200;

// const svg = d3.select('#progress-chart')
//         .append('svg')
//         .attr('width', svgWidth)
//         .attr('height', svgHeight);

// // Define xScale to map data.year to the x-coordinate
// const xScale = d3.scaleLinear()
//     .domain([2010, 2012]) // Assuming your data's years range from 2010 to 2012
//     .range([0, svgWidth]);

// // Define yScale to map data.value to the y-coordinate
// const yScale = d3.scaleLinear()
//     .domain([0, 20]) // Adjust the domain based on your data's value range
//     .range([svgHeight, 0]);

// // Now, you can use xScale and yScale in your line generator
// const line = d3.line()
//     .x(d => xScale(d.year))
//     .y(d => yScale(d.value));
// });