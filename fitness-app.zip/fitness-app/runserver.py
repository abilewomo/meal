import sys 
sys.dont_write_bytecode = True
from client import app
from flask_wtf.csrf import CSRFProtect

# Initialize and configure CSRF protection
csrf = CSRFProtect(app)

# run the application
app.run(debug=True)
