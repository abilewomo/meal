import React from 'react';
import { Link } from 'react-router-dom';
import { Stack } from '@mui/material';

const Navbar = () => (
  <Stack direction="row" justifyContent="space-around" sx={{ p: 0, m: 0, gap: { sm: '123px', xs: '40px' }, mt: { sm: '32px', xs: '20px' }, justifyContent: 'none', padding: "20px" }}>
    <Stack
      direction="row"
      gap="40px"
      fontFamily="Alegreya"
      fontSize="24px"
      alignItems="flex-end"
    >
      <Link to="/exercises" style={{ textDecoration: 'none', color: 'black', borderBottom: '3px solid #FF2625' }}>Exercise</Link>
      <a href="#exercises" style={{ textDecoration: 'none', color: 'black' }}>Details</a>
    </Stack>
  </Stack>
);

export default Navbar;
